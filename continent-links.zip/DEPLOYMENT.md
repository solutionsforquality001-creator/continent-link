# Hosting Continent Links — Step-by-Step Guide

This is a **Next.js 16 website** with a **PostgreSQL database**. To put it on the internet you need two things:

1. **A computer that runs the website** (called a host).
2. **A PostgreSQL database** (where product edits and customer orders are saved).

There are two ways to do it. Choose one:

| Option | Best for | Cost | Difficulty |
| --- | --- | --- | --- |
| **A. Vercel + Neon** (recommended) | Most people. No server maintenance. | Free to start | Easy |
| **B. Your own server (VPS)** | Full control, one monthly bill | ~$5–12/month | Medium |

You can move from A to B later. The website code does not change.

---

## What the project needs

| Item | Value |
| --- | --- |
| Node.js version | **20.9 or newer** (22 LTS recommended) |
| Install command | `npm install` |
| Build command | `npm run build` |
| Start command | `npm run start` |
| Port used | `3000` |
| Health check URL | `/api/health` (must return `{"ok":true}`) |
| Required env var 1 | `DATABASE_URL` |
| Required env var 2 | `ADMIN_PASSWORD` (protects `/admin`) |
| Owner dashboard | `https://your-domain.com/admin` |

---

# OPTION A — Vercel + Neon (recommended)

Vercel runs the website. Neon runs the PostgreSQL database. Both have free plans that are enough to launch.

## Step 1 — Put the code on GitHub

1. Create a free account at <https://github.com>.
2. Install **GitHub Desktop** (easiest, no commands) or use Git in a terminal.
3. Create a **new empty repository** called `continent-links`. Do **not** add a README.
4. Upload the project folder to that repository.

If you prefer the terminal, from inside the project folder:

```bash
git init
git add .
git commit -m "Continent Links storefront"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/continent-links.git
git push -u origin main
```

> **Never upload `.env`.** It contains your database password. It is already ignored, but double-check on GitHub that the file is not there.

## Step 2 — Create the production database

1. Sign up at <https://neon.com> (free).
2. Click **New Project**. Choose a region close to your customers (for Nigeria: **Frankfurt** or **London**).
3. Neon shows a **connection string**. It looks like:

```text
postgresql://USER:PASSWORD@ep-xxxx.eu-central-1.aws.neon.tech/neondb?sslmode=require
```

4. Copy it and keep it private. This is your `DATABASE_URL`.
5. Open the **SQL Editor** in Neon, paste the full script in the [Database setup SQL](#database-setup-sql) section below, and click **Run**. You should see three tables appear: `orders`, `order_items`, `product_overrides`.

## Step 3 — Import the project into Vercel

1. Sign up at <https://vercel.com> using your GitHub account.
2. Click **Add New → Project**.
3. Find `continent-links` and click **Import**.
4. Vercel detects Next.js automatically. Leave the build settings as they are:
   - **Framework Preset:** Next.js
   - **Build Command:** `npm run build`
   - **Output Directory:** leave empty
   - **Install Command:** `npm install`
5. Do **not** click Deploy yet. First add the environment variables in the next step.

## Step 4 — Add environment variables

Still on the import screen, open **Environment Variables** and add these two:

| Name | Value | Environments |
| --- | --- | --- |
| `DATABASE_URL` | the Neon connection string from Step 2 | Production, Preview, Development |
| `ADMIN_PASSWORD` | a strong password you choose (12+ characters) | Production, Preview, Development |

Click **Deploy**. The first build takes 1–3 minutes.

## Step 5 — Test the live site

Vercel gives you a URL such as `continent-links.vercel.app`.

Check, in this order:

1. Open the URL. The welcome page and catalog should appear.
2. Open `https://your-url/api/health`. It must show `{"ok":true}`. If it shows `{"ok":false}`, the database URL is wrong — see [Troubleshooting](#troubleshooting).
3. Search a phone model, open a product, pick a quality, add to cart, go to checkout, place a test order.
4. Open `/admin`, sign in with your `ADMIN_PASSWORD`, change one product price, save, and confirm the change on the storefront.
5. Delete the test order from the Neon SQL Editor: `DELETE FROM orders WHERE customer_name = 'Test';`

## Step 6 — Connect your domain

1. Buy a domain (e.g. `continentlinks.com`) from any registrar — Namecheap, GoDaddy, or Whogohost for `.ng` domains.
2. In Vercel: **Project → Settings → Domains → Add**.
3. Type your domain. Vercel shows exactly which DNS records to create.
4. Log in to your registrar’s DNS page and copy those records:
   - Usually an **A record** for `@` pointing to Vercel’s IP, and
   - a **CNAME record** for `www` pointing to `cname.vercel-dns.com`.
5. Save and wait. DNS can take **5 minutes to a few hours**. Vercel shows a green “Valid Configuration” when it is ready.
6. HTTPS is automatic and free.

## Step 7 — After launch

- Turn on the domain as primary so `https://continentlinks.com` is the main address.
- Enable **Vercel Analytics** (optional, free) to see visitor numbers.
- Keep the Neon project active; free databases sleep when unused and wake on the first visit.

---

# OPTION B — Your own server (VPS)

This uses an Ubuntu server. Copy each block of commands into the server terminal, one block at a time, and wait for it to finish before the next.

## Step 1 — Create the server

1. Buy an Ubuntu 22.04 or 24.04 server (1–2 GB RAM is enough) from DigitalOcean, Hetzner, Contabo, or Linode.
2. Add your SSH key during creation, or note the emailed root password.
3. Note the server’s IP address.

## Step 2 — Connect and create a user

```bash
ssh root@YOUR_SERVER_IP
adduser deploy
usermod -aG sudo deploy
```

Close the connection, then reconnect as the new user:

```bash
ssh deploy@YOUR_SERVER_IP
```

## Step 3 — Install Node.js 22

```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs git
node -v
```

## Step 4 — Install PostgreSQL

```bash
sudo apt update
sudo apt install -y postgresql
sudo systemctl enable --now postgresql
```

Create the database and a password:

```bash
sudo -u postgres psql
```

Inside the prompt, run (replace `CHOOSE_A_STRONG_PASSWORD`):

```sql
CREATE DATABASE continent_links;
CREATE USER continent WITH ENCRYPTED PASSWORD 'CHOOSE_A_STRONG_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE continent_links TO continent;
ALTER DATABASE continent_links OWNER TO continent;
\c continent_links
GRANT ALL ON SCHEMA public TO continent;
\q
```

Your connection string is:

```text
postgresql://continent:CHOOSE_A_STRONG_PASSWORD@127.0.0.1:5432/continent_links
```

## Step 5 — Create the tables

Still on the server:

```bash
psql "postgresql://continent:CHOOSE_A_STRONG_PASSWORD@127.0.0.1:5432/continent_links"
```

Paste the full script from [Database setup SQL](#database-setup-sql), then type `\q`.

## Step 6 — Upload the code

```bash
cd /var/www
sudo git clone https://github.com/YOUR-USERNAME/continent-links.git
sudo chown -R deploy:deploy /var/www/continent-links
cd /var/www/continent-links
```

## Step 7 — Create the environment file

```bash
nano .env
```

Paste (replace the values):

```env
DATABASE_URL=postgresql://continent:CHOOSE_A_STRONG_PASSWORD@127.0.0.1:5432/continent_links
ADMIN_PASSWORD=a-strong-owner-password
```

Save with `Ctrl+O`, `Enter`, then exit with `Ctrl+X`.

## Step 8 — Install, build and start

```bash
npm install
npm run build
npm install -g pm2
pm2 start npm --name continent-links -- start
pm2 save
pm2 startup
```

Run the command PM2 prints after `pm2 startup` so the site restarts after a reboot.

Check it works:

```bash
curl http://127.0.0.1:3000/api/health
```

You want `{"ok":true}`.

## Step 9 — Put Nginx and HTTPS in front

```bash
sudo apt install -y nginx
sudo nano /etc/nginx/sites-available/continent-links
```

Paste (replace the domain):

```nginx
server {
    listen 80;
    server_name continentlinks.com www.continentlinks.com;

    client_max_body_size 10M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable it and add HTTPS:

```bash
sudo ln -s /etc/nginx/sites-available/continent-links /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d continentlinks.com -d www.continentlinks.com
```

Certbot installs a free certificate and renews it automatically.

## Step 10 — Point the domain

At your domain registrar, add:

| Type | Name | Value |
| --- | --- | --- |
| A | `@` | your server IP |
| A | `www` | your server IP |

Wait for DNS to update, then open `https://continentlinks.com/api/health`.

## Step 11 — Firewall (recommended)

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

## Step 12 — Updating the site later

```bash
cd /var/www/continent-links
git pull
npm install
npm run build
pm2 restart continent-links
```

---

# Database setup SQL

Run this once in Neon’s SQL Editor, or in `psql` on your own server. It creates the three tables the app needs.

```sql
CREATE TABLE IF NOT EXISTS product_overrides (
  product_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price INTEGER NOT NULL,
  image TEXT NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  order_number TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  notes TEXT,
  subtotal INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'New',
  created_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS order_items (
  id SERIAL PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id TEXT NOT NULL,
  product_name TEXT NOT NULL,
  quality TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS order_items_order_id_idx ON order_items(order_id);
CREATE INDEX IF NOT EXISTS orders_created_at_idx ON orders(created_at DESC);
```

**Alternative for developers:** you can use Drizzle instead. Open `drizzle.config.json`, replace the URL with your hosted database URL, then run:

```bash
npx drizzle-kit push
```

The product catalog itself lives in the code (`src/lib/catalog.ts` and `src/lib/imported-products.json`). The database only stores owner price/name edits and orders.

---

# Things to customise before launch

| What | Where |
| --- | --- |
| WhatsApp number and phone links | `src/components/storefront.tsx` — the `WHATSAPP` constant and footer `tel:` links |
| WhatsApp number used in order messages | `src/app/api/orders/route.ts` |
| Company name and footer text | `src/components/storefront.tsx` |
| Product prices and names | `/admin` dashboard (no redeploy needed), or the catalog files |
| Featured products and badges | `src/lib/catalog.ts` |

After changing code files, redeploy (Vercel does this automatically when you push to GitHub; on a VPS run the update commands in Step 12).

---

# After-launch checklist

- [ ] `https://your-domain.com` loads on phone and desktop
- [ ] `/api/health` returns `{"ok":true}`
- [ ] Search finds a model, e.g. “Camo 30” or “iPhone 13”
- [ ] Product photos display correctly
- [ ] Quality selection is required before adding to cart
- [ ] A real test order appears in `/admin` and opens WhatsApp with the order text
- [ ] `/admin` is protected by your password
- [ ] HTTPS padlock is showing
- [ ] Prices and compatibility confirmed with the supplier
- [ ] Database backup schedule set (Neon has built-in history; on a VPS use `pg_dump`)

---

# Backups

**Neon:** automatic with point-in-time restore on paid plans; free plan keeps recent history. You can also export with `pg_dump`:

```bash
pg_dump "YOUR_DATABASE_URL" > backup-$(date +%F).sql
```

**Your own server:** add a daily backup with cron:

```bash
mkdir -p ~/backups
crontab -e
```

Add this line:

```cron
0 2 * * * pg_dump "postgresql://continent:PASSWORD@127.0.0.1:5432/continent_links" > ~/backups/db-$(date +\%F).sql
```

---

# Troubleshooting

| Problem | Cause | Fix |
| --- | --- | --- |
| `{"ok":false}` at `/api/health` | Wrong or missing `DATABASE_URL`, or tables not created | Re-check the connection string, then run the Database setup SQL |
| Build fails with “DATABASE_URL is required” | Variable missing during build | Add `DATABASE_URL` to the host’s environment variables and redeploy |
| `/admin` says “Owner access is not configured” | `ADMIN_PASSWORD` is not set | Add it to the environment variables and restart/redeploy |
| Admin password rejected | Password contains spaces, or old value is cached | Reset the env var, redeploy, and log in again |
| Site loads but no products | Catalog request blocked | Open `/api/catalog` directly; it should return JSON |
| Some product photos are broken | Supplier photos are hot-linked from `phonexperts.ng` | Replace those listings with your own photos in `/admin` |
| Orders do not appear in admin | Test order was deleted, or database was reset | Place a fresh test order and refresh `/admin` |
| Domain shows “Not Secure” | DNS or certificate not finished | Wait for DNS, then re-run Certbot on a VPS |
| VPS site not reachable | Nginx misconfigured or firewall closed | `sudo nginx -t`, then `sudo systemctl reload nginx`; check `sudo ufw status` |

---

# Important business notes

1. **The imported catalog is supplier reference data.** Names, prices and photos came from the PhoneXperts/JK listings so you can match parts. Confirm current prices before selling, and replace hot-linked photos with your own product photos. Photos loaded from the supplier’s server may stop working if they change their site.
2. **The catalog is large** (over 5,500 parts). It loads separately from the page so the site stays fast, but on a very slow connection the first catalog load can take a few seconds.
3. **Orders are enquiries.** Checkout saves the order and prepares a WhatsApp message; payment and delivery are confirmed by your team. No card payments are taken. If you later want online payments, add Paystack or Flutterwave and a webhook.
4. **Keep `.env` and `ADMIN_PASSWORD` private.** Never commit them to GitHub.

---

# Appendix — quick reference

**Git safety check.** Before uploading, confirm these are ignored (they are listed in `.gitignore`):

```bash
git status --short
```

`.env`, `node_modules`, and `.next` must **not** appear in the list. If `.env` ever appears, run:

```bash
git rm --cached .env
git commit -m "Remove secrets from repository"
```

Then **change your database password**, because it has been exposed.

**Minimum files that must be deployed:** everything except `node_modules`, `.next`, and `.env`. Your host will install dependencies and read the environment variables you set in its dashboard.
