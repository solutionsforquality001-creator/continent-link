import { getProducts } from "@/lib/server-catalog";

export const dynamic = "force-dynamic";

export async function GET() {
  const products = await getProducts();
  return Response.json({ products, count: products.length }, { headers: { "Cache-Control": "no-store" } });
}
