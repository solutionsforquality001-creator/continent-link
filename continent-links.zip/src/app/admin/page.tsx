import AdminPanel from "@/components/admin-panel";
import { getProducts } from "@/lib/server-catalog";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const products = await getProducts();
  return <AdminPanel products={products.slice(0, 40)} totalCount={products.length} configured={Boolean(process.env.ADMIN_PASSWORD)} />;
}
