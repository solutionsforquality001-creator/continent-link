import { db } from "@/db";
import { productOverrides } from "@/db/schema";
import importedData from "@/lib/imported-products.json";
import { catalog as baseCatalog, type Category, type Product } from "@/lib/catalog";

type ImportedTuple = [name: string, brand: string, category: string, price: number, image: string, model: string];

function thumbnail(url: string) {
  if (!/^https?:\/\//i.test(url)) return url;
  if (/-\d+x\d+\.(jpe?g|png|webp)$/i.test(url)) return url.replace(/-\d+x\d+\.(jpe?g|png|webp)$/i, "-300x300.$1");
  return url.replace(/\.(jpe?g|png|webp)$/i, "-300x300.$1");
}

function cleanName(value: string) {
  return value
    .replace(/&#8211;/g, "–").replace(/&#8212;/g, "—").replace(/&#8217;/g, "’").replace(/&#8230;|&#8230/g, "…")
    .replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&nbsp;/g, " ")
    .replace(/&#\d+;/g, "")
    .replace(/^for\s+/i, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 118)
    .trim();
}

const imported: Product[] = (importedData as ImportedTuple[]).map(([name, brand, category, price, image, model], index) => ({
  id: `px-${index}`,
  name: cleanName(name),
  brand,
  model: model || cleanName(name),
  category: (category === "Touch Pad" ? "Touch Pad" : "Screen") as Category,
  price,
  image: thumbnail(image),
  badge: /incell|in-cell/i.test(name) ? "INCELL" : /soft oled/i.test(name) ? "SOFT OLED" : /hard oled/i.test(name) ? "HARD OLED" : /amoled/i.test(name) ? "AMOLED" : undefined,
}));

const importedNames = new Map<string, string>();
for (const product of imported) {
  const key = `${product.brand}|${product.category}`;
  importedNames.set(key, `${importedNames.get(key) ?? ""} | ${product.name.toLowerCase()}`);
}
function isCovered(product: Product): boolean {
  if (product.featured || product.id.startsWith("jk-")) return false;
  const haystack = importedNames.get(`${product.brand}|${product.category}`);
  if (!haystack) return false;
  return haystack.includes(` ${product.model.toLowerCase()} `);
}

export const allProducts: Product[] = [...baseCatalog.filter((product) => !isCovered(product)), ...imported];

export async function getProducts(): Promise<Product[]> {
  const overrides = await db.select().from(productOverrides);
  if (!overrides.length) return allProducts;
  const byId = new Map(overrides.map((item) => [item.productId, item]));
  return allProducts.map((product) => {
    const edit = byId.get(product.id);
    return edit ? { ...product, name: edit.name, price: edit.price, image: edit.image } : product;
  });
}
