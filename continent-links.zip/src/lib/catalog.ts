export type Category = "Screen" | "Touch Pad";
export type Quality = "Standard" | "High quality" | "Premium";
export type Product = {
  id: string;
  name: string;
  brand: string;
  model: string;
  category: Category;
  price: number;
  image: string;
  badge?: string;
  featured?: boolean;
};
export type CartItem = { productId: string; quality: Quality; quantity: number };

export const qualities: { name: Quality; description: string; multiplier: number }[] = [
  { name: "Standard", description: "A dependable everyday option", multiplier: 1 },
  { name: "High quality", description: "An upgraded finish and feel", multiplier: 1.25 },
  { name: "Premium", description: "Our highest-grade option", multiplier: 1.5 },
];
export const qualityPrice = (price: number, quality: Quality) =>
  Math.round((price * (qualities.find((item) => item.name === quality)?.multiplier ?? 1)) / 100) * 100;
export const formatPrice = (price: number) => `₦${price.toLocaleString("en-NG")}`;
export const slug = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

const photos = {
  apple: ["/images/product-iphone.jpg", "/images/product-iphone-alt.jpg"],
  samsung: ["/images/product-samsung.jpg", "/images/product-samsung-alt.jpg"],
  android: ["/images/product-android.jpg", "/images/product-samsung-alt.jpg"],
  touch: ["/images/product-touch.jpg", "/images/product-touch-alt.jpg"],
};

const featured: Product[] = [
  { id: "featured-jk-13-pro", name: "JK Soft OLED Screen for iPhone 13 Pro", brand: "Apple", model: "iPhone 13 Pro", category: "Screen", price: 92100, image: "/images/product-iphone.jpg", badge: "FEATURED", featured: true },
  { id: "featured-samsung-a54", name: "Samsung Galaxy A54 Display Screen", brand: "Samsung", model: "Galaxy A54", category: "Screen", price: 32500, image: "/images/product-samsung.jpg", badge: "TOP PICK", featured: true },
  { id: "featured-infinix-hot-12", name: "Infinix Hot 12 LCD Screen Assembly", brand: "Infinix", model: "Hot 12", category: "Screen", price: 18500, image: "/images/product-android.jpg", badge: "GREAT VALUE", featured: true },
  { id: "featured-tecno-camon-20", name: "TECNO Camon 20 Touch Pad Digitizer", brand: "Tecno", model: "Camon 20", category: "Touch Pad", price: 10500, image: "/images/product-touch.jpg", badge: "TOP PICK", featured: true },
];

// Starting listings and prices are examples, ready for the store owner to edit.
const jkEntries: [string, string, number][] = [
  ["Soft OLED LCD", "iPhone 12 Pro Max", 80000], ["Soft OLED LCD", "iPhone XS Max", 62500],
  ["Soft OLED LCD", "iPhone 17 Pro Max", 117900], ["Soft OLED LCD", "iPhone 16 Pro Max", 93100],
  ["Soft OLED LCD", "iPhone 14 Pro Max", 71600], ["Soft OLED LCD", "iPhone 13 Pro Max", 72900],
  ["Soft OLED LCD", "iPhone 15 Pro Max", 71600], ["Hard OLED", "iPhone 16 Plus", 62500],
  ["Hard OLED", "iPhone 16", 64200], ["Hard OLED", "iPhone 15 Plus", 62500],
  ["Hard OLED", "iPhone 15", 64200], ["Soft OLED LCD", "iPhone 13 Pro", 84800],
  ["Incell LCD", "iPhone 16 Pro Max", 53400], ["Incell LCD", "iPhone 16 Pro", 52200],
  ["Hard OLED", "iPhone 14 Pro Max", 61300], ["Hard OLED", "iPhone 15 Pro Max", 61300],
  ["Hard OLED", "iPhone 15 Pro", 64200], ["Soft OLED LCD", "iPhone 14 Pro", 64200],
  ["Incell LCD", "iPhone 16 Plus", 43900], ["Incell LCD", "iPhone 16", 43100],
  ["Incell LCD", "iPhone 15 Pro Max", 45200], ["Incell LCD", "iPhone 15 Plus", 40400],
  ["Incell LCD", "iPhone 14 Pro Max", 45200], ["Soft OLED", "iPhone 13", 75600],
  ["Soft OLED", "iPhone 14", 75600], ["Soft OLED", "iPhone 12 / 12 Pro", 71200],
  ["Soft OLED LCD", "iPhone 11 Pro Max", 66600], ["Incell LCD", "iPhone 13 Pro Max", 41700],
  ["Incell TFT LCD", "iPhone 12 mini", 46400], ["Incell LCD", "iPhone 15 Pro", 39600],
  ["Incell LCD", "iPhone 14 Pro", 39600], ["Incell LCD", "iPhone 15", 39200],
  ["Incell LCD", "iPhone 12 Pro Max", 41700], ["Incell LCD", "iPhone X", 31800],
  ["Incell Material LCD", "iPhone XS Max", 33100], ["Incell LCD", "iPhone 13", 41900],
  ["Incell LCD", "iPhone 14 Plus", 67400], ["Incell LCD", "iPhone 14", 62100],
  ["Incell LCD", "iPhone 11", 31600], ["Incell LCD", "iPhone XR", 31800],
  ["Incell LCD", "iPhone XS", 31800], ["Incell LCD", "iPhone 12", 39800],
];

export const iphoneModels = [
  "iPhone 3G", "iPhone 3GS", "iPhone 4", "iPhone 4s", "iPhone 5", "iPhone 5c", "iPhone 5s",
  "iPhone 6", "iPhone 6 Plus", "iPhone 6s", "iPhone 6s Plus", "iPhone SE (2016)",
  "iPhone 7", "iPhone 7 Plus", "iPhone 8", "iPhone 8 Plus", "iPhone X", "iPhone XR", "iPhone XS",
  "iPhone XS Max", "iPhone 11", "iPhone 11 Pro", "iPhone 11 Pro Max", "iPhone SE (2020)",
  "iPhone 12 mini", "iPhone 12", "iPhone 12 Pro", "iPhone 12 Pro Max",
  "iPhone 13 mini", "iPhone 13", "iPhone 13 Pro", "iPhone 13 Pro Max", "iPhone SE (2022)",
  "iPhone 14", "iPhone 14 Plus", "iPhone 14 Pro", "iPhone 14 Pro Max",
  "iPhone 15", "iPhone 15 Plus", "iPhone 15 Pro", "iPhone 15 Pro Max",
  "iPhone 16", "iPhone 16 Plus", "iPhone 16 Pro", "iPhone 16 Pro Max", "iPhone 16e",
  "iPhone 17", "iPhone 17 Pro", "iPhone 17 Pro Max", "iPhone Air (17 Air)",
];

export const androidModels: Record<string, string[]> = {
  Samsung: [
    "Galaxy A2 Core", "Galaxy A01", "Galaxy A01 Core", "Galaxy A02", "Galaxy A02s", "Galaxy A03", "Galaxy A03s", "Galaxy A03 Core",
    "Galaxy A04", "Galaxy A04s", "Galaxy A04e", "Galaxy A05", "Galaxy A05s", "Galaxy A06", "Galaxy A06 5G",
    "Galaxy A10", "Galaxy A10s", "Galaxy A11", "Galaxy A12", "Galaxy A13", "Galaxy A13 5G", "Galaxy A14", "Galaxy A14 5G",
    "Galaxy A15", "Galaxy A15 5G", "Galaxy A16", "Galaxy A16 5G", "Galaxy A17", "Galaxy A17 5G",
    "Galaxy A20", "Galaxy A20s", "Galaxy A20e", "Galaxy A21s", "Galaxy A22", "Galaxy A22 5G", "Galaxy A23", "Galaxy A23 5G",
    "Galaxy A24", "Galaxy A25", "Galaxy A26", "Galaxy A30", "Galaxy A30s", "Galaxy A31", "Galaxy A32", "Galaxy A32 5G",
    "Galaxy A33", "Galaxy A34", "Galaxy A35", "Galaxy A36", "Galaxy A40", "Galaxy A50", "Galaxy A50s", "Galaxy A51",
    "Galaxy A52", "Galaxy A52s", "Galaxy A53", "Galaxy A54", "Galaxy A55", "Galaxy A56", "Galaxy A60", "Galaxy A70",
    "Galaxy A70s", "Galaxy A71", "Galaxy A72", "Galaxy A73", "Galaxy A80",
    "Galaxy S7", "Galaxy S7 Edge", "Galaxy S8", "Galaxy S8 Plus", "Galaxy S9", "Galaxy S9 Plus",
    "Galaxy S10", "Galaxy S10e", "Galaxy S10 Plus", "Galaxy S10 Lite",
    "Galaxy S20", "Galaxy S20 FE", "Galaxy S20 Plus", "Galaxy S20 Ultra",
    "Galaxy S21", "Galaxy S21 FE", "Galaxy S21 Plus", "Galaxy S21 Ultra",
    "Galaxy S22", "Galaxy S22 Plus", "Galaxy S22 Ultra", "Galaxy S23", "Galaxy S23 FE", "Galaxy S23 Plus", "Galaxy S23 Ultra",
    "Galaxy S24", "Galaxy S24 FE", "Galaxy S24 Plus", "Galaxy S24 Ultra",
    "Galaxy S25", "Galaxy S25 FE", "Galaxy S25 Plus", "Galaxy S25 Ultra", "Galaxy S25 Edge",
    "Galaxy Note 5", "Galaxy Note 8", "Galaxy Note 9", "Galaxy Note 10", "Galaxy Note 10 Lite", "Galaxy Note 10 Plus",
    "Galaxy Note 20", "Galaxy Note 20 Ultra",
    "Galaxy Z Fold 3", "Galaxy Z Fold 4", "Galaxy Z Fold 5", "Galaxy Z Fold 6", "Galaxy Z Fold 7",
    "Galaxy Z Flip 3", "Galaxy Z Flip 4", "Galaxy Z Flip 5", "Galaxy Z Flip 6", "Galaxy Z Flip 7",
    "Galaxy M11", "Galaxy M12", "Galaxy M13", "Galaxy M21", "Galaxy M22", "Galaxy M31", "Galaxy M32", "Galaxy M33", "Galaxy M51",
    "Galaxy J2", "Galaxy J4", "Galaxy J5", "Galaxy J6", "Galaxy J7", "Galaxy J7 Pro J730", "Galaxy J7 Prime", "Galaxy J8",
  ],
  Infinix: [
    "Hot 5", "Hot 6", "Hot 6 Pro", "Hot 7", "Hot 7 Pro", "Hot 8", "Hot 9", "Hot 9 Play",
    "Hot 10", "Hot 10 Play", "Hot 10i", "Hot 11", "Hot 11 Play", "Hot 11S", "Hot 12", "Hot 12 Play", "Hot 12 Pro",
    "Hot 20", "Hot 20i", "Hot 30", "Hot 30i", "Hot 30 Play", "Hot 40", "Hot 40i", "Hot 40 Pro",
    "Hot 50", "Hot 50i", "Hot 50 Pro", "Hot 60", "Hot 60i", "Hot 60 Pro",
    "Smart 2", "Smart 3", "Smart 4", "Smart 5", "Smart 6", "Smart 6 Plus", "Smart 7", "Smart 8", "Smart 9", "Smart 10",
    "Note 5", "Note 6", "Note 7", "Note 8", "Note 10", "Note 10 Pro", "Note 11", "Note 11 Pro", "Note 12", "Note 12 Pro",
    "Note 30", "Note 30 Pro", "Note 40", "Note 40 Pro", "Note 40 Pro Plus", "Note 50", "Note 50 Pro",
    "Zero 5", "Zero 6", "Zero 8", "Zero X", "Zero X Pro", "Zero 20", "Zero 30", "Zero 40", "Zero Ultra",
    "GT 10 Pro", "GT 20 Pro",
  ],
  Tecno: [
    "Camon 11", "Camon 12", "Camon 12 Air", "Camon 12 Pro", "Camon 15", "Camon 15 Air", "Camon 16", "Camon 16 Premier",
    "Camon 17", "Camon 17 Pro", "Camon 18", "Camon 18 Pro", "Camon 19", "Camon 19 Pro",
    "Camon 20", "Camon 20 Pro", "Camon 20 Premier", "Camon 30", "Camon 30 Pro", "Camon 30 Premier",
    "Camon 40", "Camon 40 Pro", "Camon 40 Premier",
    "Spark 4", "Spark 5", "Spark 6", "Spark 7", "Spark 7 Pro", "Spark 8", "Spark 8C", "Spark 9", "Spark 10", "Spark 10 Pro",
    "Spark 20", "Spark 20 Pro", "Spark 20C", "Spark 30", "Spark 30C", "Spark Go 2023", "Spark Go 2024", "Spark Go 2025",
    "Pop 2", "Pop 3", "Pop 4", "Pop 5", "Pop 6", "Pop 6 Pro", "Pop 7", "Pop 8", "Pop 9",
    "Pova", "Pova 2", "Pova 3", "Pova 4", "Pova 5", "Pova 5 Pro", "Pova 6", "Pova 6 Pro", "Pova 7",
    "Phantom 6", "Phantom 8", "Phantom X", "Phantom X2", "Phantom X2 Pro", "Phantom V Fold", "Phantom V Flip",
  ],
  itel: [
    "A15", "A16", "A21", "A23", "A23S", "A33", "A36", "A41", "A44", "A44 Air", "A44 Power", "A45", "A55", "A56", "A56 Pro",
    "A58", "A60", "A60s", "A70", "A80", "P15", "P32", "P33", "P36", "P38", "P40", "P55", "P65",
    "S15", "S16", "S17", "S18", "S23", "S24", "S25", "Vision 1", "Vision 2", "Vision 3", "Vision 3 Plus", "RS4",
  ],
  Xiaomi: [
    "Redmi 4X", "Redmi 5", "Redmi 5A", "Redmi 5 Plus", "Redmi 6", "Redmi 6 Pro", "Redmi 7", "Redmi 8", "Redmi 8A",
    "Redmi 9", "Redmi 9A", "Redmi 9C", "Redmi 9T", "Redmi 10", "Redmi 10A", "Redmi 10C", "Redmi 12", "Redmi 12C",
    "Redmi 13", "Redmi 13C", "Redmi 14C", "Redmi 15C",
    "Redmi Note 5", "Redmi Note 5A", "Redmi Note 5 Pro", "Redmi Note 7", "Redmi Note 7 Pro", "Redmi Note 8",
    "Redmi Note 8 Pro", "Redmi Note 8T", "Redmi Note 9", "Redmi Note 9S", "Redmi Note 9 Pro", "Redmi Note 9 Pro Max",
    "Redmi Note 10", "Redmi Note 10 Pro", "Redmi Note 11", "Redmi Note 11 Pro", "Redmi Note 12", "Redmi Note 12 Pro",
    "Redmi Note 13", "Redmi Note 13 Pro", "Redmi Note 13 Pro Plus", "Redmi Note 14", "Redmi Note 14 Pro", "Redmi Note 14 Pro Plus",
    "Mi A1", "Mi A2", "Mi A2 Lite", "Mi A3", "Mi 8 Lite", "Mi 9 Lite", "Mi 9T", "Mi 9T Pro", "Mi 10T", "Mi 10T Pro",
    "Mi Note 10", "Mi Note 10 Lite", "Mi Note 10 Pro", "Xiaomi 11T", "Xiaomi 12", "Xiaomi 13", "Xiaomi 14", "Xiaomi 15",
    "Poco M3", "Poco M4", "Poco M5", "Poco M6", "Poco X3", "Poco X5", "Poco X6", "Poco F5", "Poco F6",
  ],
  Oppo: [
    "A3s", "A5", "A5s", "A12", "A15", "A16", "A17", "A18", "A31", "A33", "A37", "A38", "A53", "A54", "A55", "A57", "A58",
    "A60", "A74", "A77", "A78", "A79", "A92", "A93", "A98", "F9", "F11", "F11 Pro", "F19", "F21 Pro", "F23",
    "Reno 2", "Reno 3", "Reno 4", "Reno 5", "Reno 6", "Reno 7", "Reno 8", "Reno 10", "Reno 11", "Reno 12", "Reno 13",
    "Find X3 Pro", "Find X5 Pro", "Find X6 Pro", "Find X8",
  ],
  Vivo: [
    "Y11", "Y12", "Y15", "Y16", "Y17", "Y19", "Y20", "Y21", "Y22", "Y27", "Y28", "Y33s", "Y35", "Y36", "Y91",
    "V15", "V19", "V20", "V21", "V23", "V25", "V27", "V29", "V30", "V40", "X60", "X70", "X80", "X90", "X100",
  ],
  Huawei: [
    "Y5", "Y6", "Y7", "Y7 Prime", "Y9 (2019)", "Y9 Prime", "Y9s", "P20", "P20 Pro", "P30", "P30 Lite", "P30 Pro",
    "P40", "P40 Lite", "P40 Pro", "P50 Pro", "P60 Pro", "Nova 3i", "Nova 5T", "Nova 7i", "Nova 9", "Nova 11", "Nova 12",
    "Mate 20", "Mate 20 Pro", "Mate 30", "Mate 40 Pro", "Mate 50 Pro",
  ],
  Honor: [
    "8X", "9X", "10", "10 Lite", "20", "50", "50 Lite", "70", "90", "X6", "X7", "X8", "X9", "X9b",
    "Magic 4", "Magic 5 Pro", "Magic 6 Pro",
  ],
  Realme: [
    "C11", "C12", "C15", "C20", "C21", "C25", "C30", "C33", "C35", "C53", "C55", "C61", "C67",
    "Note 50", "Narzo 50", "Narzo 60", "7", "8", "9", "10", "11", "12", "12 Pro", "13 Pro",
  ],
  Nokia: [
    "1", "2", "2.1", "2.3", "3", "3.1", "3.2", "5", "5.1", "6", "6.1", "7 Plus", "8",
    "C1", "C2", "C10", "C20", "C21", "C30", "C31", "G10", "G20", "G21", "G42", "X10", "X20", "X30",
  ],
  Motorola: [
    "Moto E6", "Moto E7", "Moto E13", "Moto G7", "Moto G8", "Moto G9", "Moto G10", "Moto G20", "Moto G30",
    "Moto G Power", "Moto G50", "Moto G54", "Moto G84", "Moto G Stylus", "Edge 20", "Edge 30", "Edge 40", "Edge 50",
  ],
  Google: [
    "Pixel 3", "Pixel 3a", "Pixel 4", "Pixel 4a", "Pixel 5", "Pixel 5a", "Pixel 6", "Pixel 6 Pro",
    "Pixel 7", "Pixel 7 Pro", "Pixel 7a", "Pixel 8", "Pixel 8 Pro", "Pixel 8a", "Pixel 9", "Pixel 9 Pro",
  ],
  OnePlus: [
    "6", "6T", "7", "7 Pro", "8", "8 Pro", "9", "9 Pro", "10 Pro", "11", "12", "13",
    "Nord", "Nord 2", "Nord 3", "Nord N10", "Nord N20", "Nord CE 3",
  ],
  Sony: [
    "Xperia 1", "Xperia 1 II", "Xperia 1 III", "Xperia 1 IV", "Xperia 1 V", "Xperia 5", "Xperia 5 II", "Xperia 5 III",
    "Xperia 10", "Xperia 10 II", "Xperia 10 III", "Xperia 10 IV", "Xperia 10 V", "Xperia L3", "Xperia L4",
  ],
  Nothing: ["Phone (1)", "Phone (2)", "Phone (2a)", "Phone (2a) Plus", "Phone (3)", "Phone (3a)", "Phone (3a) Pro"],
  ZTE: [
    "Blade A3", "Blade A5", "Blade A7", "Blade A31", "Blade A51", "Blade A52", "Blade V30", "Blade V40", "Blade V50",
    "Axon 20", "Axon 30", "Axon 40 Pro", "Nubia RedMagic 6R", "Nubia RedMagic 8 Pro", "Nubia Neo 2",
  ],
  Asus: ["Zenfone 8", "Zenfone 9", "Zenfone 10", "Zenfone 11 Ultra", "ROG Phone 5", "ROG Phone 6", "ROG Phone 7", "ROG Phone 8"],
  Lenovo: ["K6 Note", "K8 Note", "K10 Note", "Z5", "Z6 Pro", "ZUK Z2", "Legion Duel", "Legion Y70"],
  Meizu: ["16th", "17 Pro", "18", "18 Pro", "20", "21", "Note 9"],
  Lava: ["Blaze 2", "Agni 2", "Agni 5G", "Z2", "Z6", "Storm 5G"],
  Wiko: ["Y50", "Y60", "Y62", "Power U10", "Power U20", "View 5", "T50", "T60"],
  Alcatel: ["1B", "1S", "3L", "3X", "5V", "5X", "1S 2021"],
  Sharp: ["Aquos R6", "Aquos R7", "Aquos Sense 6", "Aquos Sense 7"],
  TCL: ["20 Pro", "20L", "30 SE", "30 Plus", "40 SE", "50 Pro", "505"],
  Gionee: ["M5", "M6", "M7", "S10", "S11", "F100", "F103", "F205", "P5", "P7", "P8", "P12"],
  Umidigi: ["A3", "A5 Pro", "A7", "A7 Pro", "A9", "A11", "A13", "Bison", "F1", "F2", "G9"],
  BlackBerry: ["KeyOne", "Key2", "Key2 LE", "Motion", "DTEK60"],
  HTC: ["Desire 20 Pro", "Desire 21 Pro", "U11", "U12 Plus", "U23 Pro", "Wildfire E3"],
  LG: ["G4", "G6", "G8 ThinQ", "V30", "V50 ThinQ", "Velvet", "K40", "K61"],
};

export const brands = ["Apple", ...Object.keys(androidModels)];

const roundPrice = (value: number) => Math.max(3000, Math.round(value / 100) * 100);

function iphoneScreenPrice(model: string) {
  const name = model.replace("iPhone ", "");
  if (name.startsWith("SE")) return 14000;
  if (name.startsWith("Air")) return 88000;
  if (name.startsWith("17")) return 98000;
  if (name.startsWith("16")) return 82000;
  if (name.startsWith("15")) return 64000;
  if (name.startsWith("14")) return 54000;
  if (name.startsWith("13")) return 45000;
  if (name.startsWith("12")) return 39000;
  if (name.startsWith("11")) return 34000;
  if (name.startsWith("XS") || name.startsWith("XR") || name === "X") return 30000;
  if (name.startsWith("8")) return 22000;
  if (name.startsWith("7")) return 18500;
  if (name.startsWith("6")) return 15500;
  if (name.startsWith("5")) return 12500;
  if (name.startsWith("4")) return 11000;
  return 10000;
}
function applePrice(model: string, category: Category) {
  let screen = iphoneScreenPrice(model);
  const name = model.replace("iPhone ", "");
  if (name.includes("Pro Max")) screen += 18000;
  else if (name.includes("Pro")) screen += 10000;
  else if (name.includes("Plus")) screen += 7000;
  else if (name.includes("Max")) screen += 12000;
  else if (name.includes("mini")) screen -= 4000;
  if (name === "16e") screen -= 18000;
  return roundPrice(category === "Screen" ? screen : screen * 0.36);
}
function samsungPrice(model: string, category: Category) {
  const name = model.replace("Galaxy ", "");
  let screen = 18000;
  if (name.includes("Fold")) screen = 115000;
  else if (name.includes("Flip")) screen = 82000;
  else if (name.includes("Ultra")) screen = 92000;
  else if (/^S\d+/.test(name)) {
    const generation = Number(name.match(/^S(\d+)/)?.[1] ?? 10);
    screen = 26000 + Math.max(0, generation - 8) * 5200;
  } else if (name.startsWith("Note")) screen = 52000;
  else if (/^A\d+/.test(name)) screen = 16000 + Math.min(Number(name.match(/^A(\d+)/)?.[1] ?? 10), 80) * 280;
  else if (name.startsWith("M")) screen = 15500;
  else if (name.startsWith("J")) screen = 12500;
  if (name.includes("FE")) screen -= 6000;
  if (name.includes("Lite")) screen -= 4000;
  return roundPrice(category === "Screen" ? screen : screen * 0.32);
}
const androidBase: Record<string, number> = {
  Infinix: 14500, Tecno: 13500, itel: 10000, Xiaomi: 17500, Oppo: 17000, Vivo: 17000, Huawei: 18500,
  Honor: 17500, Realme: 16000, Nokia: 13000, Motorola: 15500, Google: 36000, OnePlus: 31000, Sony: 33000,
  Nothing: 30000, ZTE: 14000, Asus: 26000, Lenovo: 13000, Meizu: 14500, Lava: 10000, Wiko: 9500,
  Alcatel: 9000, Sharp: 18000, TCL: 11000, Gionee: 9000, Umidigi: 10500, BlackBerry: 12000,
  HTC: 14000, LG: 13500,
};
function androidPrice(brand: string, model: string, category: Category) {
  let screen = androidBase[brand] ?? 14000;
  if (/Note/.test(model)) screen += 3000;
  if (/Pro|Plus|Max|Ultra/.test(model)) screen += 3500;
  if (/Fold|Flip/.test(model)) screen += 26000;
  if (/Zero|Phantom|Find X|Magic|Premium|GT /.test(model)) screen += 6000;
  if (/Premier|Pro Plus|Pro Max|Fold|Flip/.test(model)) screen += 8000;
  if (/^S\d+|^A\d+/.test(model.replace("Galaxy ", ""))) screen = brand === "Samsung" ? samsungPrice(model, "Screen") : screen;
  return roundPrice(category === "Screen" ? screen : screen * 0.35);
}
function displayName(brand: string, model: string) {
  return brand === "Apple" ? model : `${brand} ${model}`;
}

const jkProducts: Product[] = jkEntries.map(([kind, model, price], index) => ({
  id: `jk-${slug(kind)}-${slug(model)}-${index}`, name: `JK ${kind} Screen for ${model}`,
  brand: "Apple", model, category: "Screen", price,
  image: photos.apple[index % photos.apple.length], badge: "JK DISPLAY",
}));

const appleProducts: Product[] = iphoneModels.flatMap((model, index) =>
  (["Screen", "Touch Pad"] as Category[]).map((category) => ({
    id: `apple-${slug(model)}-${category === "Screen" ? "screen" : "touch"}`,
    name: `${model} ${category === "Screen" ? "Screen Assembly" : "Touch Pad Digitizer"}`,
    brand: "Apple", model, category, price: applePrice(model, category),
    image: category === "Touch Pad" ? photos.touch[index % photos.touch.length] : photos.apple[index % photos.apple.length],
  }))
);

const androidProducts: Product[] = Object.entries(androidModels)
  .flatMap(([brand, models], brandIndex) =>
    [...new Set(models)].flatMap((model, index) =>
      (["Screen", "Touch Pad"] as Category[]).map((category) => ({
        id: `${slug(brand)}-${slug(model)}-${category === "Screen" ? "screen" : "touch"}`,
        name: `${displayName(brand, model)} ${category === "Screen" ? "Screen Assembly" : "Touch Pad Digitizer"}`,
        brand, model, category,
        price: brand === "Samsung" ? samsungPrice(model, category) : androidPrice(brand, model, category),
        image: category === "Touch Pad"
          ? photos.touch[(index + brandIndex) % photos.touch.length]
          : brand === "Samsung"
            ? photos.samsung[(index + brandIndex) % photos.samsung.length]
            : photos.android[(index + brandIndex) % photos.android.length],
      }))
    )
  );

const seen = new Set<string>();
export const catalog: Product[] = [...featured, ...jkProducts, ...appleProducts, ...androidProducts].filter((product) => {
  if (seen.has(product.id)) return false;
  seen.add(product.id);
  return true;
});
