# Continent Links

Phone screens and touch pads storefront for iPhone and Android.

- **Storefront:** welcome page, searchable catalog, wishlist, quality selection, cart, checkout and WhatsApp order confirmation.
- **Owner dashboard:** `/admin` — edit product names, prices and image URLs, and review orders.
- **Stack:** Next.js 16 (App Router), React 19, Tailwind CSS 4, PostgreSQL with Drizzle ORM.

## Run locally

```bash
npm install
npx drizzle-kit push   # create the database tables
npm run dev            # http://localhost:3000
```

Create a `.env` file with:

```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
ADMIN_PASSWORD=choose-a-strong-password
```

## Deploy

See **[DEPLOYMENT.md](./DEPLOYMENT.md)** for a full step-by-step hosting guide (Vercel + Neon, or your own Ubuntu server).

## Useful commands

| Command | Purpose |
| --- | --- |
| `npm run dev` | Local development |
| `npm run build` | Production build |
| `npm run start` | Run the production build |
| `npm run typecheck` | TypeScript check |
| `npx drizzle-kit push` | Apply schema changes |
| `GET /api/health` | Health check |
